@extends('layouts/app')
@section('content')
    <h1>Упс... Страница не найдена</h1>
    <br>
    <h3 style="align-content: center; color: red"><a href="{{route('live')}}">Вернутся на Главную</a></h3>
@endsection
